<?php get_header(); ?>


<div id="content">

  <div class="title-head"><h1>404 ERROR - Not Found</h1></div>
  <div class="content-404">
    <h4>The page you requested does not exist.</h4>
  </div><!-- end .content-404 -->

</div><!-- end #content -->

	
<?php get_footer(); ?>